package service;

import dao.AdminDAO;
import model.Admin;
import model.AdminRole;
import util.BCryptUtil;

public class BootstrapService {
    private final AdminDAO adminDAO = new AdminDAO();

    public void ensureDefaultAdmin() {
        try {
            adminDAO.upsertDefaultAdmin(new Admin("System Super Admin", "admin", BCryptUtil.hash("admin123"), AdminRole.SUPER_ADMIN));
        } catch (Exception ignored) {
            // The login screen still opens when the database is not configured yet.
        }
    }
}
